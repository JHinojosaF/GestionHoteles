/*
-- Query: SELECT * FROM gestionhoteldb.insumo
LIMIT 0, 1000

-- Date: 2022-07-01 23:04
*/
INSERT INTO `` (`idInsumo`,`NombreInsumo`,`CantidadDisponible`) VALUES (1,'Toallas',400);
INSERT INTO `` (`idInsumo`,`NombreInsumo`,`CantidadDisponible`) VALUES (2,'Jabon',400);
INSERT INTO `` (`idInsumo`,`NombreInsumo`,`CantidadDisponible`) VALUES (3,'pan',399);

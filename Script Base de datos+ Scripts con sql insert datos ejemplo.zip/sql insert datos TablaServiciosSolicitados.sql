/*
-- Query: SELECT * FROM gestionhoteldb.serviciossolicitados
LIMIT 0, 1000

-- Date: 2022-07-01 23:05
*/
INSERT INTO `` (`idServiciosSolicitados`,`idFactura`,`idServicio`) VALUES (111,1,1);
INSERT INTO `` (`idServiciosSolicitados`,`idFactura`,`idServicio`) VALUES (112,1,2);
INSERT INTO `` (`idServiciosSolicitados`,`idFactura`,`idServicio`) VALUES (113,1,3);
INSERT INTO `` (`idServiciosSolicitados`,`idFactura`,`idServicio`) VALUES (114,2,1);
INSERT INTO `` (`idServiciosSolicitados`,`idFactura`,`idServicio`) VALUES (115,2,4);

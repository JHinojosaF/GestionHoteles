/*
-- Query: SELECT * FROM gestionhoteldb.habitacion
LIMIT 0, 1000

-- Date: 2022-07-01 23:04
*/
INSERT INTO `` (`idHabitaciones`,`ValorHabitación`,`CantidadCamas`,`EstadoHabitación`) VALUES (101,'99000','4',1);
INSERT INTO `` (`idHabitaciones`,`ValorHabitación`,`CantidadCamas`,`EstadoHabitación`) VALUES (102,'90000','3',0);
INSERT INTO `` (`idHabitaciones`,`ValorHabitación`,`CantidadCamas`,`EstadoHabitación`) VALUES (103,'85000','3',0);
INSERT INTO `` (`idHabitaciones`,`ValorHabitación`,`CantidadCamas`,`EstadoHabitación`) VALUES (201,'75000','4',1);
INSERT INTO `` (`idHabitaciones`,`ValorHabitación`,`CantidadCamas`,`EstadoHabitación`) VALUES (202,'60000','2',0);
INSERT INTO `` (`idHabitaciones`,`ValorHabitación`,`CantidadCamas`,`EstadoHabitación`) VALUES (301,'80000','1',0);

/*
-- Query: SELECT * FROM gestionhoteldb.factura
LIMIT 0, 1000

-- Date: 2022-07-01 23:04
*/
INSERT INTO `` (`idFactura`,`idReserva`,`Fecha`,`NombreCliente`,`RutCliente`,`Total`) VALUES (1,2,'2022-06-28','alberto','1.111.111-1',0);
INSERT INTO `` (`idFactura`,`idReserva`,`Fecha`,`NombreCliente`,`RutCliente`,`Total`) VALUES (2,1,'2022-06-29','','1.234.567-8',0);

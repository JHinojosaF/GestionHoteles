/*
-- Query: SELECT * FROM gestionhoteldb.reserva
LIMIT 0, 1000

-- Date: 2022-07-01 23:05
*/
INSERT INTO `` (`idReserva`,`HabitaciónReservada`,`DiasReserva`) VALUES (1,101,'3');
INSERT INTO `` (`idReserva`,`HabitaciónReservada`,`DiasReserva`) VALUES (2,201,'2');

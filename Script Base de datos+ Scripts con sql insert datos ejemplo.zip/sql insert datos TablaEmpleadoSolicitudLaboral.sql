/*
-- Query: SELECT * FROM gestionhoteldb.solicitudlaboral
LIMIT 0, 1000

-- Date: 2022-07-01 23:05
*/
INSERT INTO `` (`idSolicitudLaboral`,`idEmpleado`,` NombreSolicitante`,`RutSolicitante`,`TelefonoSolicitante`,`CargoDeseado`,`ObservacionesSolicitante`) VALUES (56,'9.876.543-2','pedro','2.304.566-8','145','R.Humanos','tabien');
INSERT INTO `` (`idSolicitudLaboral`,`idEmpleado`,` NombreSolicitante`,`RutSolicitante`,`TelefonoSolicitante`,`CargoDeseado`,`ObservacionesSolicitante`) VALUES (67,'9.876.543-2','juanita','18.325.676-3','531','Finanzas','tamal');
INSERT INTO `` (`idSolicitudLaboral`,`idEmpleado`,` NombreSolicitante`,`RutSolicitante`,`TelefonoSolicitante`,`CargoDeseado`,`ObservacionesSolicitante`) VALUES (88,'9.876.543-2','shrek','6.666.666-6','2333','Recepcionista','tamaomeno');

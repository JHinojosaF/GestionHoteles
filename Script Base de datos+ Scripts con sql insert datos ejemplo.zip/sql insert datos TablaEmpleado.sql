/*
-- Query: SELECT * FROM gestionhoteldb.empleado
LIMIT 0, 1000

-- Date: 2022-07-01 23:03
*/
INSERT INTO `` (`RutEmpleado`,`NombreEmpleado`,`TelefonoContacto`,`Cargo`,`Sueldo`,`Horario`,`Correo`,`Observaciones`) VALUES ('19.757.944-7','Jose','133','Recepcionista',2,'lunes-viernes','si@gmail.com','si');
INSERT INTO `` (`RutEmpleado`,`NombreEmpleado`,`TelefonoContacto`,`Cargo`,`Sueldo`,`Horario`,`Correo`,`Observaciones`) VALUES ('8.888.888-8','Alberto','1333','finanzas',3,'lunes-viernes','no@gmail.com','no');
INSERT INTO `` (`RutEmpleado`,`NombreEmpleado`,`TelefonoContacto`,`Cargo`,`Sueldo`,`Horario`,`Correo`,`Observaciones`) VALUES ('9.876.543-2','Pancracio','311','R.Humanos',1,'lunes-jueves','puedeser@gmail.com','puede ser');

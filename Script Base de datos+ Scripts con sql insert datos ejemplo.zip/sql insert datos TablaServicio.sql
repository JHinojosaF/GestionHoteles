/*
-- Query: SELECT * FROM gestionhoteldb.servicio
LIMIT 0, 1000

-- Date: 2022-07-01 23:05
*/
INSERT INTO `` (`idServicio`,`idInsumo`,`rutEmpleado`,`NombreServicio`,`CostoServicio`) VALUES (1,1,'19.757.944-7','Toallas base','300');
INSERT INTO `` (`idServicio`,`idInsumo`,`rutEmpleado`,`NombreServicio`,`CostoServicio`) VALUES (2,NULL,'19.757.944-7','Masaje','100');
INSERT INTO `` (`idServicio`,`idInsumo`,`rutEmpleado`,`NombreServicio`,`CostoServicio`) VALUES (3,2,'19.757.944-7','Jabon base','300');
INSERT INTO `` (`idServicio`,`idInsumo`,`rutEmpleado`,`NombreServicio`,`CostoServicio`) VALUES (4,3,'19.757.944-7','Pan a la habitacion','50');
